Made by Dexrn
I wanted to port the Plastic Texture Pack to Classic (this all happened while playing Good Old Lava Survival)
I know there was already a port made but it's missing several things, such as the lava texture, magma texture, crate texture is just crafting table top texture, UI, lava and water animations, etc.